<div class="ui grid" style="min-height:100%;">
  <div class="twelve wide stretched column" style="height:100%;">
    <div class="ui segment" style="height:100%;">
        <div id="summernote" style="height:100%;">Hello Summernote</div>
    </div>
  </div>
  <div class="four wide column">
    <div class="ui vertical fluid right tabular menu">
      <a class="item">
        Bio
      </a>
      <a class="item">
        Pics
      </a>
      <a class="item active">
        Companies
      </a>
      <a class="item">
        Links
      </a>
    </div>
  </div>
</div>
<script>cloadFinish();</script>
