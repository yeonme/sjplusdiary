<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = 'Purenman_4824';
$dbname = 'apistuff';
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);

global $dbcon;
$dbcon = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if ($dbcon === false) {
    die('ERROR: mysql connect fail');
}
mysqli_set_charset($dbcon, 'utf8mb4');
